from flask import render_template, redirect, url_for, session, request, jsonify
from flask_login import login_required
from bokeh.plotting import figure
from bokeh.embed import json_item
from bokeh.palettes import Category20c
from bokeh.transform import cumsum
from bokeh.models.tools import SaveTool, HoverTool
from app.libs.mysql.mysql_db import DB
from config import bug_resolution, bug_cause, bug_env
from math import pi
import pandas as pd
from datetime import datetime

from . import main
from .. import db
from app.libs.common.common import get_date_list_with_two_days
from ..modules import User, and_, Project, ReportDict, ProjectConfig


@main.route('/', methods=['GET'])
def index():
    return redirect(url_for('auth.login'))


@main.route('/project/<int:user_id>', methods=["GET"])
@login_required
def project(user_id):
    user = User.query.filter(and_(User.id == user_id, User.del_flag == 'N')).first()
    projects = Project.query.filter(Project.owned_by == user_id).all()
    return render_template("project.html", user=user, projects=projects)


@main.route('/user/edit', methods=['POST'])
@login_required
def user_edit():
    user_id = request.form.get("user_id")
    user = User.query.filter(User.id == user_id).first()
    if user:
        tmp = dict()
        tmp["id"] = user.id
        tmp["user_name"] = user.user_name
        tmp["password"] = user.password_hash
        # tmp["QQ"] =user.QQ
        # tmp["MSN"] = user.MSN
        tmp["phone"] = user.mobile_phone
        tmp["mail"] = user.mail
        return jsonify({"data": tmp, "status": 200})
    else:
        return jsonify({"ErrMsg": "User not found!", "status": 400}), 400


@main.route('/user/edit/save', methods=['POST'])
@login_required
def user_edit_save():
    user_id = request.form.get("user_id")
    password = request.form.get("password")
    # qq = request.form.get("qq")
    # msn = request.form.get("msn")
    phone = request.form.get("phone")
    mail = request.form.get("mail")

    user = User.query.filter(User.id == user_id).first()
    if password != user.password_hash:
        user.password_hash = user.encrypt_password(password)
    user.mobile_phone = phone
    user.mail = mail
    db.session.commit()
    return jsonify({"Message": "Update user successfully!",
                    "url": url_for('main.index'), "new_password": user.password_hash, "status": 200})


@main.route('/project/delete', methods=['POST'])
@login_required
def project_delete():
    project_id = request.form.get("project_id")
    user_id = request.form.get("user_id")
    project = Project.query.filter(and_(Project.id == project_id, Project.owned_by == user_id)).first()
    db.session.delete(project)
    db.session.commit()
    return jsonify({"Message": "Delete project successfully!", "status": 200})


@main.route('/project/config', methods=['POST'])
@login_required
def project_config():
    try:
        project_id = request.form.get("project_id")
        user_id = request.form.get("user_id")
        report_items = ReportDict.query.all()
        report_item_list = []
        selected_item_list = []
        for row in report_items:
            report_item_list.append({"dict_id": row.id, "dict_name": row.name})
        configed_items = ProjectConfig.query.filter(and_(ProjectConfig.project_id == project_id,
                                                         ProjectConfig.user_id == user_id)).all()
        for row in configed_items:
            selected_item_list.append(row.dict_id)
        return jsonify({"Message": "Get dashboard configuration successfully!",
                        "report_items": report_item_list,
                        "selected_items": selected_item_list,
                        "status": 200})
    except:
        return jsonify({"ErrMsg": "Failed to get dashboard dicts!", "status": 400}), 400


@main.route('/project/config/save', methods=['POST'])
@login_required
def project_config_save():
    try:
        project_id = request.form.get("project_id")
        user_id = request.form.get("user_id")
        config_items = request.form.get("config_items")
        config_items_list = config_items.split(',')
        report_dict = dict(zip([x for x in config_items_list if config_items_list.index(x) % 2 == 0],
                               [x for x in config_items_list if config_items_list.index(x) % 2 != 0]))
        for key in report_dict.keys():
            if ProjectConfig.query.filter(and_(ProjectConfig.dict_id == int(key),
                                               ProjectConfig.user_id == int(user_id)),
                                          ProjectConfig.project_id == int(project_id)).first():
                continue
            else:
                insReportItem = ProjectConfig(dict_id=int(key), project_id=project_id, user_id=user_id)
                db.session.add(insReportItem)
                db.session.commit()
        before_remove = ProjectConfig.query.filter(and_(ProjectConfig.user_id == int(user_id)),
                                          ProjectConfig.project_id == int(project_id)).all()
        for item in before_remove:
            if str(item.dict_id) not in report_dict.keys():
                delete_config = ProjectConfig.query.filter(and_(ProjectConfig.project_id == project_id,
                                                                ProjectConfig.user_id == user_id,
                                                                ProjectConfig.dict_id == item.dict_id)).first()
                db.session.delete(delete_config)
                db.session.commit()
        return jsonify({"Message": "Save project dashboard config successfully!", "status": 200})
    except:
        return jsonify({"ErrMsg": "Failed to save dashboard config!", "status": 400}), 400


@main.route('/project', methods=['POST'])
@login_required
def project_list():
    user_id = request.form.get("user_id")
    try:
        sync_projects = Project.query.filter(Project.owned_by == user_id).all()
        sync_projects_list = []
        for item in sync_projects:
            sync_projects_list.append(dict(zip(["project_id", "project_name"], [item.id, item.project_name])))
        conn = DB()
        zentao_project_list = []
        sql_statement = 'select id as project_id, name as project_name from zt_product'
        data_set = conn.query_mysql(sql_statement)
        for data in data_set:
            zentao_project_list.append(data)
        return jsonify({"Message": "Zentao project list returned successfully!",
                        "projects": zentao_project_list,
                        "sync_projects": sync_projects_list,
                        "status": 200})
    except:
        return jsonify({"ErrMsg": "Failed to connect to Zentao!", "status": 400}), 400


@main.route('/projectsync', methods=["POST"])
@login_required
def project_sync():
    projects = request.form.get("projects")
    owned_by = request.form.get("user_id")
    projects = projects.split(',')
    project_dict = dict(zip([x for x in projects if projects.index(x) % 2 == 0],
                            [x for x in projects if projects.index(x) % 2 != 0]))
    for key in project_dict.keys():
        if Project.query.filter(and_(Project.id == int(key), Project.owned_by == owned_by)).first():
            continue
        else:
            insProject = Project(id=int(key), project_name=project_dict[key], owned_by=owned_by)
            db.session.add(insProject)
            db.session.commit()
    return jsonify({"Message": "Sync project successfully!", "status": 200})


@main.route('/project/<int:project_id>/sprint', methods=["GET"])
@login_required
def sprint(project_id):
    project = Project.query.filter(Project.id == project_id).first()
    conn = DB()
    sql_statement = 'select id as sprint_id, name as sprint_name from  zt_project where deleted="0" and id in ' \
                    '(select project from zt_projectproduct where product=' + str(project_id) + ');'
    data_set = conn.query_mysql(sql_statement)
    conn.close()
    return render_template("sprint.html", project=project, sprints=data_set)


@main.route('/project/sprint/report', methods=["POST"])
@login_required
def sprint_report():
    project_id = request.form.get("project_id")
    user_id = request.form.get("user_id")
    sprint_id = request.form.get("sprint_id")
    if sprint_id == "-1":
        return jsonify({"ErrMsg": "Please select one sprint, then generate the report!", "status": 400}), 400
    config_set = ProjectConfig.query.filter(and_(ProjectConfig.project_id == project_id, ProjectConfig.user_id == user_id)).all()
    if config_set:
        return_content = {"Message": "successfully!", "status": 200}
        conn = DB()
        # total_bug_sql
        total_bugs_sql = "select count(*) as cnt from zt_bug where project=" + str(sprint_id) + ";"
        total_bugs = conn.query_mysql(total_bugs_sql)
        total_bugs_num = total_bugs[0]['cnt']
        # total_fixed_bug_sql
        total_fixed_bugs_sql = "select count(*) as cnt from zt_bug where resolution='fixed' and project=" + str(sprint_id) + ";"
        total_fixed_bugs = conn.query_mysql(total_fixed_bugs_sql)
        total_fixed_bugs_num = total_fixed_bugs[0]['cnt']
        if total_bugs_num:
            for item in config_set:
                if item.dict_id == 1:
                    source_data = {}
                    # bug_resolution sql
                    dist_bugs_sql = "select resolution, count(*) as cnt from zt_bug where deleted='0' and project=" + str(sprint_id) + " GROUP BY resolution;"
                    dist_bugs = conn.query_mysql(dist_bugs_sql)
                    for dist_item in dist_bugs:
                        source_data[bug_resolution[dist_item['resolution']]] = dist_item['cnt']
                    data = pd.Series(source_data).reset_index(name='value').rename(columns={'index': 'resolution'})
                    data['angle'] = data['value']/data['value'].sum() * 2 * pi
                    data['color'] = Category20c[len(source_data)]
                    p = figure(title="解决方案", height=350,
                               tools=[HoverTool(), SaveTool()],
                               tooltips='@resolution: @value' + " / " + str(total_bugs_num), x_range=(-0.5, 1.0))
                    p.wedge(x=0, y=1, radius=0.4, start_angle=cumsum('angle', include_zero=True),
                            end_angle=cumsum('angle'), line_color='white', fill_color='color',
                            legend_field='resolution', source=data)
                    p.toolbar.autohide = True
                    p.axis.axis_label = None
                    p.axis.visible = False
                    p.grid.grid_line_color = None
                    json_content = json_item(p, 'bug_resolution')
                    return_content['bug_resolution'] = json_content

                if item.dict_id == 2:
                    source_data = {}
                    # bug_cause_catalog sql
                    cata_bugs_sql = "select type, count(*) as cnt from zt_bug where deleted='0' and project=" + str(
                        sprint_id) + " GROUP BY type;"
                    cata_bugs = conn.query_mysql(cata_bugs_sql)
                    for cata_item in cata_bugs:
                        source_data[bug_cause[cata_item['type']]] = cata_item['cnt']
                    data = pd.Series(source_data).reset_index(name='value').rename(columns={'index': 'type'})
                    data['angle'] = data['value'] / data['value'].sum() * 2 * pi
                    data['color'] = Category20c[len(source_data)]
                    p = figure(title="Bug类型", height=350,
                               tools=[HoverTool(), SaveTool()],
                               tooltips='@type: @value' + " / " + str(total_bugs_num), x_range=(-0.5, 1.0))
                    p.wedge(x=0, y=1, radius=0.4, start_angle=cumsum('angle', include_zero=True),
                            end_angle=cumsum('angle'), line_color='white', fill_color='color',
                            legend_field='type', source=data)
                    p.toolbar.autohide = True
                    p.axis.axis_label = None
                    p.axis.visible = False
                    p.grid.grid_line_color = None
                    json_content = json_item(p, 'bug_cause_catalog')
                    return_content['bug_cause_catalog'] = json_content

                if item.dict_id == 3:
                    source_data = {}
                    # bug_priority_catalog sql
                    cata_bugs_sql = "SELECT severity, count(*) as cnt from zt_bug " \
                                    "where deleted='0' and resolution='fixed' and project=" + str(sprint_id) + \
                                    " GROUP BY severity order by severity asc;"
                    cata_bugs = conn.query_mysql(cata_bugs_sql)
                    for cata_item in cata_bugs:
                        source_data[cata_item['severity']] = cata_item['cnt']
                    priority_list = []
                    value_list = []
                    for key, value in source_data.items():
                        priority_list.append(key)
                        value_list.append(value)
                    p = figure(title='严重程度', height=350, tools=[HoverTool(), SaveTool()], tooltips='数量: @top',
                               x_axis_label='严重程度', y_axis_label='数量')
                    if len(priority_list) < 4:
                        for i in range(1, 5):
                            if i not in priority_list:
                                priority_list.append(i)
                                value_list.append(0)
                    p.vbar(x=priority_list, top=value_list, width=0.5, bottom=0, color='green')
                    p.toolbar.autohide = True
                    p.axis.visible = True
                    p.grid.grid_line_color = None
                    json_content = json_item(p, 'bug_priority_catalog')
                    return_content['bug_priority_catalog'] = json_content

                if item.dict_id == 4:
                    source_data = {}
                    # bug_reopen_catalog sql
                    cata_bugs_sql = "SELECT activatedCount, count(*) as cnt from zt_bug " \
                                    "where deleted='0' and activatedCount > 0 and resolution='fixed' and project=" + \
                                    str(sprint_id) + " GROUP BY activatedCount order by activatedCount asc;"
                    cata_bugs = conn.query_mysql(cata_bugs_sql)
                    for cata_item in cata_bugs:
                        source_data[cata_item['activatedCount']] = cata_item['cnt']
                    reopen_list = []
                    value_list = []
                    for key, value in source_data.items():
                        reopen_list.append(key)
                        value_list.append(value)
                    p = figure(title='激活次数', height=350, tools=[HoverTool(), SaveTool()], tooltips='数量: @top',
                               x_axis_label='激活次数', y_axis_label='数量')
                    if len(reopen_list) < 4:
                        for i in range(1, 5):
                            if i not in reopen_list:
                                reopen_list.append(i)
                                value_list.append(0)
                    p.vbar(x=reopen_list, top=value_list, width=0.5, bottom=0, color='green')
                    p.toolbar.autohide = True
                    p.axis.visible = True
                    p.grid.grid_line_color = None
                    json_content = json_item(p, 'bug_reopen_catalog')
                    return_content['bug_reopen_catalog'] = json_content

                if item.dict_id == 5:
                    source_data = {}
                    # bug_env_catalog sql
                    cata_bugs_sql = "SELECT env, count(*) as cnt from zt_bug where " \
                                    "deleted='0' and resolution='fixed' and project=" + \
                                    str(sprint_id) + " GROUP BY env;"
                    cata_bugs = conn.query_mysql(cata_bugs_sql)
                    temp_bugs = cata_bugs[:]
                    unassigned = 0
                    for row in cata_bugs:
                        if row['env'] is None or row['env'].strip() == '':
                            unassigned = unassigned + row['cnt']
                            temp_bugs.remove(row)
                    if unassigned > 0:
                        temp_bugs.append({"env": "", "cnt": unassigned})
                    for cata_item in temp_bugs:
                        source_data[bug_env[cata_item['env']]] = cata_item['cnt']
                    data = pd.Series(source_data).reset_index(name='value').rename(columns={'index': 'env'})
                    data['angle'] = data['value'] / data['value'].sum() * 2 * pi
                    data['color'] = Category20c[len(source_data)]
                    p = figure(title="Bug环境", height=350,
                               tools=[HoverTool(), SaveTool()],
                               tooltips='@env: @value' + " / " + str(total_fixed_bugs_num), x_range=(-0.5, 1.0))
                    p.wedge(x=0, y=1, radius=0.4, start_angle=cumsum('angle', include_zero=True),
                            end_angle=cumsum('angle'), line_color='white', fill_color='color',
                            legend_field='env', source=data)
                    p.toolbar.autohide = True
                    p.axis.axis_label = None
                    p.axis.visible = False
                    p.grid.grid_line_color = None
                    json_content = json_item(p, 'bug_env_catalog')
                    return_content['bug_env_catalog'] = json_content

                if item.dict_id == 6:
                    source_data = {}
                    # bug_trend sql
                    date_period_sql = "select begin, end from zt_project where id=" + str(sprint_id) + ";"
                    bug_date_map_sql = "select SUBSTR(openedDate,1,10) as date_time, count(*) as cnt from zt_bug " \
                                       "where deleted='0' and project=" + str(sprint_id) + \
                                       " GROUP BY SUBSTR(openedDate,1,10) ORDER BY date_time asc;"
                    date_period = conn.query_mysql(date_period_sql)
                    sprint_period = get_date_list_with_two_days(str(date_period[0]['begin']), str(date_period[0]['end']))
                    bug_date_map = conn.query_mysql(bug_date_map_sql)
                    for cata_item in bug_date_map:
                        source_data[cata_item['date_time']] = cata_item['cnt']
                    dashboard_dict = {}
                    for date_item in sprint_period:
                        dashboard_dict[date_item] = source_data.get(date_item, 0)
                    sprint_per_day_cnt = list(dashboard_dict.values())
                    datetime_sprint_period = []
                    for i in range(len(sprint_period)):
                        datetime_sprint_period.append(datetime.strptime(sprint_period[i], '%Y-%m-%d'))
                    p = figure(title="Bug趋势", x_axis_type="datetime",  height=350,
                               tools=[HoverTool(), SaveTool()],
                               tooltips='数量: @y')
                    p.circle(x=datetime_sprint_period, y=sprint_per_day_cnt, size=10)
                    p.line(x=datetime_sprint_period, y=sprint_per_day_cnt, color='navy', line_width=2)
                    p.toolbar.autohide = True
                    json_content = json_item(p, 'bug_trend_catalog')
                    return_content['bug_trend_catalog'] = json_content
            conn.close()
            return jsonify(return_content), 200
        else:
            return jsonify({"Message": "Congratulations, no bug has been opened till now!", "status": 200}), 200
    else:
        return jsonify({"ErrMsg": "Please config project first by clicking Config button!", "status": 400}), 400


@main.route('/project/<int:project_id>/customize', methods=["GET"])
@login_required
def customize():
    return jsonify({"Message": "Function is developing...", "status": 200})

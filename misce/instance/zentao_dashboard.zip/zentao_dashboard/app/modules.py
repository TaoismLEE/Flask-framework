from . import db, login_manager, and_, or_
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin


class User(UserMixin, db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True, nullable=False)
    user_name = db.Column(db.String(25))
    password_hash = db.Column(db.String(128))
    mobile_phone = db.Column(db.String(11))
    mail = db.Column(db.String(255))
    avator = db.Column(db.Text)
    del_flag = db.Column(db.String(1))

    def __init__(self, username, password, phone="", mail="", photo="", flag="N"):
        self.user_name = username
        self.password_hash = self.encrypt_password(password)
        self.mobile_phone = phone
        self.mail = mail
        self.avator = photo
        self.del_flag = flag

    @property
    def password(self):
        raise AttributeError('password is not a readable attribute')

    def encrypt_password(self, password):
        return generate_password_hash(password)

    def verify_password(self, password):
        return check_password_hash(self.password_hash, password)


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(user_id)


class Project(db.Model):
    __tablename__ = "project"
    id = db.Column(db.Integer, primary_key=True, nullable=False)
    project_logo = db.Column(db.Text)
    project_name = db.Column(db.String(50))
    incharger = db.Column(db.String(50))
    mobile_phone = db.Column(db.String(11))
    owned_by = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    cc_emails = db.Column(db.String(1000))


class ReportDict(db.Model):
    __tablename__ = "report_dict"
    id = db.Column(db.Integer, primary_key=True, nullable=False)
    name = db.Column(db.String(50))
    description = db.Column(db.String(500))


class ProjectConfig(db.Model):
    __tablename__ = "project_config"
    id = db.Column(db.Integer, primary_key=True, nullable=False)
    project_id = db.Column(db.Integer, nullable=False)
    dict_id = db.Column(db.Integer, nullable=False)
    user_id = db.Column(db.Integer, nullable=False)
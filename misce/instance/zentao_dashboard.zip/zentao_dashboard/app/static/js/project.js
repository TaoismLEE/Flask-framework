$(document).ready(function(){
    //pop up regist dialog
    $('#registerProject').click(function () {
        $("#myModalLabel").text("Project Sync");
        $("#myModal").modal('show');
        $("div.modal-header button:first").addClass("hiddenElement");
        $("#btn_regist>span").text("Sync");
        $("#checkbox-hub").empty();

        //API call
        const request = new XMLHttpRequest();
        request.open("POST", "/project");

        //deal with feedback
        request.onload = function() {
            const result = JSON.parse(request.responseText);
            if (result.status == 200) {
                projects = result.projects;
                sync_projects = result.sync_projects;
                var flag = 0
                for (i=0; i < projects.length; i++){
                    for (j=0; j < sync_projects.length; j++){
                        if (projects[i].project_id == sync_projects[j].project_id && flag == 0){
                            html_content = '<div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="' + projects[i].project_id + '" checked><label class="custom-control-label" for="' + projects[i].project_id + '">' + projects[i].project_name + '</label></div>';
                            $("#checkbox-hub").append(html_content);
                            flag = 1;
                        }
                    }
                    if (flag == 1){
                        flag = 0;
                        }
                    else{
                        html_content = '<div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="' + projects[i].project_id + '"><label class="custom-control-label" for="' + projects[i].project_id + '">' + projects[i].project_name + '</label></div>';
                        $("#checkbox-hub").append(html_content);
                    }
                }
                }
            else
                error_msg(result.ErrMsg);
        };

        //send request
        const paras = new FormData();
        paras.append("user_id", localStorage.getItem("user"));
        request.send(paras);
    });

    //submit sync
    $("#btn_regist").click(function() {
        if($("#myModalLabel").text() == "Project Sync"){
            const request = new XMLHttpRequest();
            const owned_by = localStorage.getItem("user");
            const checkbox_elements = $("div#checkbox-hub input");
            var checked_projects = [];
            $.each(checkbox_elements, function(index, value){
                if(value.checked){
                    var project_id = value.getAttribute("id");
                    checked_projects.push(project_id);
                    var project_name = value.nextSibling.innerHTML;
                    checked_projects.push(project_name);
                };
            });


            //API call
            request.open("POST", "/projectsync");

            //deal with feedback
            request.onload = function() {
                const result = JSON.parse(request.responseText);
                if (result.status == 200) {
                    success_msg(result.Message);
                    $("#myModal").modal('hide');
                    setTimeout(function(){
                        window.location.reload();
                        }, 2100);
                    }
                else
                    error_msg(result.ErrMsg);
            };

            //send request
            const paras = new FormData();
            paras.append("projects", checked_projects)
            paras.append("user_id", owned_by);
            request.send(paras);
        }
        else  if ($("#myModalLabel").text() == "Report Config"){
            const request = new XMLHttpRequest();
            const user_id = localStorage.getItem("user");
            const project_id = localStorage.getItem("project_id");
            const checkbox_elements = $("div#checkbox-hub input");
            var checked_items = [];
            $.each(checkbox_elements, function(index, value){
                if(value.checked){
                    var report_id = value.getAttribute("id");
                    checked_items.push(report_id);
                    var report_name = value.nextSibling.innerHTML;
                    checked_items.push(report_name);
                };
            });


            //API call
            request.open("POST", "/project/config/save");

            //deal with feedback
            request.onload = function() {
                const result = JSON.parse(request.responseText);
                if (result.status == 200) {
                    $("#myModal").modal('hide');
                    success_msg(result.Message);
                    setTimeout(function(){
                        window.location.reload();
                        }, 2100);
                    }
                else
                    error_msg(result.ErrMsg);
            };

            //send request
            const paras = new FormData();
            paras.append("config_items", checked_items);
            paras.append("user_id", user_id);
            paras.append("project_id", project_id);
            request.send(paras);
        }
    });

    // logout system
    $("#signOut").click(function(){
        const request = new XMLHttpRequest();
        request.open("POST", "/auth/logout");
        request.onload = function(){
            const result = JSON.parse(request.responseText);
            if (result.status == 200) {
                window.location.replace(result.url);
                }
        };
        const paras = new FormData();
        request.send(paras);
    });

    // trigger editing user pop-up dialogue
    $("#editUser").click(function(){
    const request = new XMLHttpRequest();
    user_id = localStorage.getItem('user');
    console.log(user_id)

    request.open("POST", "/user/edit");
    request.onload = function(){
        const result = JSON.parse(request.responseText);
        if (result.status == 200) {
            //open edit modal
            $("#myModal2").modal('show');
            $("#myModalLabel2").text("Edit User");
            $("div.modal-header button:last").addClass("hiddenElement");
            $("#btn_submit2>span").text("Save");

            //write back user data
            $("#txt_user_name").val(result.data.user_name);
            $("#password").val(result.data.password);
//            $("#txt_qq").val(result.data.QQ);
//            $("#txt_MSN").val(result.data.MSN);
            $("#txt_phone").val(result.data.phone);
            $("#txt_mail").val(result.data.mail);

//            //save login password
//            localStorage.setItem("password", result.data.PASSWORD);
            }
        return;
    };
    const paras = new FormData();
    paras.append("user_id", user_id)
    request.send(paras);
    });

    // Save edited user data
    $("#btn_submit2").click(function() {
        if($("#myModalLabel2").text() == "Edit User"){
            const request = new XMLHttpRequest();
            const username = $("#txt_user_name").val();
            const password = $("#password").val();
//            const qq = $("#txt_qq").val();
//            const msn = $("#txt_MSN").val();
            const phone = $("#txt_phone").val();
            const mail = $("#txt_mail").val();
            const user_id = localStorage.getItem('user');
            console.log(user_id)
            //const photo = $("#txt_img").val();
            if (password == "") {
                warning_msg("Password is required!");
                return;
                return;
            }

            // API call
            request.open("POST", "/user/edit/save");

            // deal with feedback
            request.onload = function() {
                const result = JSON.parse(request.responseText);
                if (result.status == 200) {
                    success_msg(result.Message);
                    $("#myModal2").modal('hide');
                    let new_password = result.new_password;
                    let old_password = localStorage.getItem("password");
                    if (new_password == old_password){
                        return;
                    }
                    else{
                        window.location.replace(result.url);
                        localStorage.setItem("password", "");
                        localStorage.setItem("user", "");
                        }
                    }
                else
                    error_msg(result.ErrMsg);
            };

            //send request
            const paras = new FormData();
            paras.append("username", username);
            paras.append("password", password);
//            paras.append("qq", qq);
//            paras.append("msn", msn);
            paras.append("phone", phone);
            paras.append("mail", mail);
            //paras.append("photo", photo);
            paras.append("user_id", user_id);
            request.send(paras);
        }
    });
    document.querySelectorAll(".btn-outline-secondary").forEach(function(e){
        e.onclick = function(){
            //get project_id and action name
            project_id = $(this).parent().parent().parent().children('span').text();
            user_id = localStorage.getItem('user');
            action = $(this).text();

            if (action == "Delete") {
                bootbox.confirm({
                message: "<span style='font-size: 1.2rem; padding: 10px;'>Are you sure to delete?</span>",
                buttons: {
                    confirm: {
                        label: 'Yes',
                        className: 'btn-success'
                    },
                    cancel: {
                        label: 'No',
                        className: 'btn-danger'
                    }
                    },
                callback: function (result) {
                    if (result){


                        const request = new XMLHttpRequest();
                        request.open("POST", "/project/delete");
                        request.onload = function(){
                            const result = JSON.parse(request.responseText);
                            if (result.status == 200) {
                                success_msg(result.Message);
                                setTimeout(function(){
                                    window.location.reload();
                                    }, 2100);
                                }
                        };
                        const paras = new FormData();
                        paras.append("project_id", project_id);
                        paras.append("user_id", user_id);
                        request.send(paras);
                    }
                }
                });
            }
            else {
                $("#myModalLabel").text("Report Config");
                $("#myModal").modal('show');
                $("div.modal-header button:first").addClass("hiddenElement");
                $("#btn_regist>span").text("Submit");
                $("#checkbox-hub").empty();

                //save config project_id
                localStorage.setItem("project_id", project_id);

                const request = new XMLHttpRequest();
                request.open("POST", "/project/config");
                request.onload = function(){
                    const result = JSON.parse(request.responseText);
                    if (result.status == 200) {
                        //show config dialog
                        report_items = result.report_items;
                        selected_items = result.selected_items;
                        var flag = 0
                        for (i=0; i < report_items.length; i++){
                            for (j=0; j < selected_items.length; j++){
                                if (report_items[i].dict_id == selected_items[j] && flag == 0){
                                    html_content = '<div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="' + report_items[i].dict_id + '" checked><label class="custom-control-label" for="' + report_items[i].dict_id + '">' + report_items[i].dict_name + '</label></div>';
                                    $("#checkbox-hub").append(html_content);
                                    flag = 1;
                                }
                            }
                            if (flag == 1){
                                flag = 0;
                                }
                            else{
                                html_content = '<div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="' + report_items[i].dict_id + '"><label class="custom-control-label" for="' + report_items[i].dict_id + '">' + report_items[i].dict_name + '</label></div>';
                                $("#checkbox-hub").append(html_content);
                            }
                        }
                        return;
                        }
                    else {
                        error_msg(result.ErrMsg);
                    }
                };
                const paras = new FormData();
                paras.append("project_id", project_id);
                paras.append("user_id", user_id);
                request.send(paras);
            }
        };
    });
});
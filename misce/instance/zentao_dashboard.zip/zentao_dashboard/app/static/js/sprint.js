$(document).ready(function(){
    //generate sprint report according to config
    $('#generateReport').click(function () {
        const project_id = $("label").attr("id");
        const user_id = localStorage.getItem("user");
        const sprint_id = $("select[id='inputState'] option:selected").attr("id");
        const chart_elements = $("div.row div:first-child");
        $.each(chart_elements, function(index, value){
            value.innerHTML='';
        });
        const chart_desc_elements = $("div.row div:last-child");
        $.each(chart_desc_elements, function(index, value){
            value.setAttribute('class', 'chart-desc-display');
        });

        //API call
        const request = new XMLHttpRequest();
        request.open("POST", "/project/sprint/report");

        //deal with feedback
        request.onload = function() {
            const result = JSON.parse(request.responseText);
            if (result.status == 200 && result.Message == 'successfully!') {
                if (result.bug_resolution){
                    Bokeh.embed.embed_item(result.bug_resolution);
                    $('#bug_resolution_desc').removeClass('chart-desc-display');
                };
                if (result.bug_cause_catalog){
                    Bokeh.embed.embed_item(result.bug_cause_catalog);
                    $('#bug_cause_catalog_desc').removeClass('chart-desc-display');
                };
                if (result.bug_priority_catalog){
                    Bokeh.embed.embed_item(result.bug_priority_catalog);
                    $('#bug_priority_catalog_desc').removeClass('chart-desc-display');
                };
                if (result.bug_reopen_catalog){
                    Bokeh.embed.embed_item(result.bug_reopen_catalog);
                    $('#bug_reopen_catalog_desc').removeClass('chart-desc-display');
                };
                if (result.bug_env_catalog){
                    Bokeh.embed.embed_item(result.bug_env_catalog);
                    $('#bug_env_catalog_desc').removeClass('chart-desc-display');
                };
                if (result.bug_trend_catalog){
                    Bokeh.embed.embed_item(result.bug_trend_catalog);
                    $('#bug_trend_catalog_desc').removeClass('chart-desc-display');
                };
            }
            else if (result.status == 200 && result.Message != 'successfully!'){
                success_msg(result.Message);
            }
            else
                error_msg(result.ErrMsg);
        };

        //send request
        const paras = new FormData();
        paras.append("project_id", project_id);
        paras.append("user_id", user_id);
        paras.append("sprint_id", sprint_id);
        request.send(paras);
    });
});
from flask import render_template, redirect, url_for, request, jsonify
from . import auth
from ..modules import db, User, and_
from flask_login import logout_user, login_user, login_required


@auth.route('/signup', methods=["POST"])
def sign_up():
    username = request.form.get("username")
    password = request.form.get("password")
    phone = request.form.get("phone")
    mail = request.form.get("mail")
    # photo = request.form.get("photo")

    user = User.query.filter(and_(User.user_name == username, User.del_flag == 'N')).first()
    if user:
        return jsonify({"ErrMsg": "Username already used, try another one please!", "status": 400}), 400
    else:
        new_user = User(username=username, password=password, phone=phone, mail=mail)
        db.session.add(new_user)
        db.session.commit()
        return jsonify({"Message": "Sign up successfully!", "status": 200}), 200


@auth.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get("username")
        password = request.form.get("password")
        remember_me = request.form.get("remember_me")

        user = User.query.filter(and_(User.user_name == username, User.del_flag == 'N')).first()
        if user and user.verify_password(password):
            if remember_me:
                login_user(user, remember=True)
            return jsonify({"Message": "Sign in successfully!", "url": "/project",
                            "user": user.id, "password": user.password_hash, "status": 200})
        else:
            return jsonify({"ErrMsg": "Username or password is wrong!", "status": 400})

    return render_template('auth/login.html')


@auth.route('/logout', methods=["POST"])
@login_required
def logout():
    logout_user()
    return jsonify({"Message": "Logout successfully!", "url": url_for('main.index'), "status": 200})


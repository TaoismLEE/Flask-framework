# -*- coding:utf-8 -*-
from config import basedir
import logging.config

# read logger config
logging.config.fileConfig(basedir + r'\app\libs\log\logger.ini')

# select logger object
logger = logging.getLogger("loggerObj")

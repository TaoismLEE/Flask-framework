# _*_ coding:utf-8 _*_
from pymysql import connect, cursors
from pymysql.err import OperationalError
from ..log.log import logger
from config import Zentao

# --------- 读取zentao配置 ---------------
host = Zentao.host
port = Zentao.port
user = Zentao.zentao_user
password = Zentao.zentao_password
db = Zentao.schema


class DB:
    """
    MySQL基本操作
    """
    def __init__(self):
        try:
            # connect to MySql
            self.conn = connect(host=host,
                                user=user,
                                password=password,
                                port=port,
                                db=db,
                                charset='utf8',
                                cursorclass=cursors.DictCursor
                                )
        except OperationalError as e:
            logger.info("Mysql Error %d: %s" % (e.args[0], e.args[1]))

    # clear table data
    def clear(self, table_name):
        real_sql = "delete from " + table_name + ";"
        with self.conn.cursor() as cursor:
            # cancel foreign key forbidden
            cursor.execute("SET FOREIGN_KEY_CHECKS=0;")
            cursor.execute(real_sql)
        self.conn.commit()

    # insert table data
    def insert(self, table_name, table_data):
        for key in table_data:
            table_data[key] = "'"+str(table_data[key])+"'"
        key = ','.join(table_data.keys())
        value = ','.join(table_data.values())
        real_sql = "INSERT INTO " + table_name + " (" + key + ") VALUES (" + value + ")"

        with self.conn.cursor() as cursor:
            cursor.execute(real_sql)
        self.conn.commit()

    # close connection
    def close(self):
        self.conn.close()

    # initial db
    def init_data(self, datas):
        for table, data in datas.items():
            self.clear(table)
            for d in data:
                self.insert(table, d)
        self.close()

    # execute query
    def query_mysql(self, sql):
        with self.conn.cursor() as cursor:
            cursor.execute(sql)
            rows = cursor.fetchall()
            if len(rows) == 0:
                logger.info(u"No SQL Query Data Returned!")
            return rows

import datetime


def get_date_list_with_two_days(day_start, day_end):
    sprint_period = []
    start_year = int(day_start[:4])
    start_month = int(day_start[5:7])
    start_day = int(day_start[8:])
    end_year = int(day_end[:4])
    end_month = int(day_end[5:7])
    end_day = int(day_end[8:])
    d1 = datetime.date(start_year, start_month, start_day)
    d2 = datetime.date(end_year, end_month, end_day)
    days = [d1 + datetime.timedelta(days=x) for x in range((d2-d1).days + 1)]

    for day in days:
        sprint_period.append(day.strftime('%Y-%m-%d'))

    return sprint_period

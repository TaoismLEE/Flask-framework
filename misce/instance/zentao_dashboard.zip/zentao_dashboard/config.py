import os
basedir = os.path.abspath(os.path.dirname(__file__))


class Config:
    SECRET_KEY = 'h$MN1a2b34'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    JSON_AS_ASCII = False

    @staticmethod
    def init_app(app):
        pass


class DevelopmentConfig(Config):
    SQLALCHEMY_DATABASE_URI = "mysql+pymysql://" + "edms_test" + ":" + "Dtt123456" + "@" + "10.81.128.55" + "/edms_db_1001"


class TestConfig(Config):
    SQLALCHEMY_DATABASE_URI = "mysql+pymysql://" + "root" + ":" + "h$MN1a2b34" + "@" + "10.173.42.72" + "/zentao"


class ProductionConfig(Config):
    SQLALCHEMY_DATABASE_URI = "mysql+pymysql://" + "root" + ":" + "h$MN1a2b34" + "@" + "10.173.42.72" + "/zentao"


config = {
    'development': DevelopmentConfig,
    'test': TestConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig
}

mail = {
    'sender': 'yuliy@deloitte.com.cn',
    'password': 'xxxxx'
}


class Zentao:
    host = '10.173.20.9'
    port = 3307
    zentao_user = 'analysisUser'
    zentao_password = '2wsx6TRd2ws5r'
    schema = 'zentao'


bug_resolution = {
    "fixed": "已解决",
    "bydesign": "设计如此",
    "duplicate": "重复Bug",
    "external": "外部原因",
    "postponed": "延期处理",
    "willnotfix": "不予解决",
    "notrepro": "无法重现",
    "story_chg": "需求变更无需解决",
    "tostory": "转为需求",
    "tostory1": "转需求",
    "": "遗留Bug"
}

bug_cause = {
    "codeerror": "开发-代码错误",
    "interface": "开发-优化建议",
    "designdefect": "开发-设计缺陷",
    "functionmissing": "开发-功能缺失",
    "automation": "开发-脚本错误",
    "config": "开发-配置错误",
    "dataerror": "开发-数据问题",
    "standard": "开发-代码规范",
    "compatibilityerror": "开发-兼容问题",
    "performance": "开发-性能问题",
    "security": "开发-安全问题",
    "requirementerror": "需求-需求错误",
    "requirementadvice": "需求-需求建议",
    "requiredchange": "需求-需求变更",
    "requirementadd": "需求-需求新增【客户】",
    "install": "运维-环境相关",
    "others": "其他",
    "": "未知类型"
}

bug_env = {
    "test": "测试环境",
    "uat": "UAT环境",
    "pre": "PRE环境",
    "production": "生产环境",
    "": "未分配"
}
